This is RFC5766-TURN-SERVER development repository
=================================================
 transitioned from the legacy Google Code site to Github
---------------------------------------------------------------
 Follow the links for the project information:
-------------------------------------------------

[Downloads: source tarball and the platform builds, for the latest version 3.2.5.9](http://turnserver.open-sys.org/downloads/v3.2.5.9/)

[Turn Server](README.turnserver)

[Turn Admin Tool](README.turnadmin)

[Turn Utilities](README.turnutils)

[Legacy wiki pages](https://code.google.com/p/rfc5766-turn-server/w/list)

[Legacy rfc5766-turn-server project site (the parent project)](https://code.google.com/p/rfc5766-turn-server/)
